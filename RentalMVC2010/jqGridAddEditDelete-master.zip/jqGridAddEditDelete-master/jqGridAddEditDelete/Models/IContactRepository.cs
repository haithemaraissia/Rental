﻿namespace jqGridAddEditDelete.Models
{
    public interface IContactRepository : IRepositoryWithTypedId<ContactViewModel, System.Guid>
    {
    }
}